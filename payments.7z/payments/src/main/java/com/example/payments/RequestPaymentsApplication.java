package com.example.payments;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class    RequestPaymentsApplication {

	public static void main(String[] args) {
		SpringApplication.run(RequestPaymentsApplication.class, args);
	}

}
