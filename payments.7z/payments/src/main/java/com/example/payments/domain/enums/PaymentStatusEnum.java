package com.example.payments.domain.enums;

public enum PaymentStatusEnum {
    PENDING,DONE,CANCELED
}
