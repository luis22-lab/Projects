package com.example.payments.domain.enums;

public enum AccountStatusEnum {
    LOCKED,ACTIVATED
}
