package com.example.payments.domain.enums;

public enum PaymentMethod {
    TRANSFERENCIA ,CHEQUE,CRYPTOMONEDA;
}
