package com.example.payments.domain.usecase;

import com.example.payments.api.Dto.PaymentDto;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.test.context.junit.jupiter.SpringExtension;

@ExtendWith(MockitoExtension.class)
public class CreatePaymentUseCaseTest {

    @Test
    public void testCreatePaymentUseCase() {


       // PaymentDto paymentDto = new PaymentDto();
    }




}
